const frsNumber = +prompt("Please, enter one number", "");

const scdNumber = +prompt("Please, enter second number", "");

const calcOper = `Calculations are finished!
Sum: ${frsNumber} + ${scdNumber} = ${frsNumber + scdNumber}
Diff: ${frsNumber} - ${scdNumber} = ${frsNumber - scdNumber}
Mult: ${frsNumber} * ${scdNumber} = ${frsNumber * scdNumber}
Div: ${frsNumber} / ${scdNumber} = ${frsNumber / scdNumber}`;

alert(calcOper);

//Console
console.log(calcOper);

