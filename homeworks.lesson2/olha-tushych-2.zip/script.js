const number1 = +prompt("Enter first number:");

const number2 = +prompt("Enter second number:");

const mySum = number1 + number2;

const myDiff = number1 - number2;

const myMult = number1 * number2;

const myDiv = number1 / number2;

console.log("Calculations are finished!" + "\n"
    + "Sum: " + number1 + "+" + number2 + "=" + mySum + "\n"
    + "Diff: " + number1 + "-" + number2 + "=" + myDiff + "\n"
    + "Mult: " + number1 + "*" + number2 + "=" + myMult + "\n"
    + "Div: " + number1 + "/" + number2 + "=" + myDiv);

alert("Calculations are finished!" + "\n"
    + "Sum: " + number1 + "+" + number2 + "=" + mySum + "\n"
    + "Diff: " + number1 + "-" + number2 + "=" + myDiff + "\n"
    + "Mult: " + number1 + "*" + number2 + "=" + myMult + "\n"
    + "Div: " + number1 + "/" + number2 + "=" + myDiv);