
let firstNumber = prompt("Введите первое число");
secondNumber = prompt("Введите второе число");

result = alert(` Результат умножения = ${firstNumber * secondNumber}; 
 Результат вычитания = ${firstNumber - secondNumber};
 Результат сложения = ${Number(firstNumber) + Number(secondNumber)};
 Резултат деления = ${firstNumber / secondNumber};`);

console.log("result");