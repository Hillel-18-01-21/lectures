alert("Hello!");

const userName = prompt("What is your name?");

alert("Nice to meet you, " + userName);